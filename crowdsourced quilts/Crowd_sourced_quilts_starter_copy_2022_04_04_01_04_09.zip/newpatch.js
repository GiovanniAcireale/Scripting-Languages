class NewPatch extends Block {
  constructor(width, height, backColor, patchColor1, patchColor2 ) {
    super( width, height, backColor) ;
    this.patchColor1 = patchColor1 ;
    this.patchColor2 = patchColor2 ;
  }

  // Can you overload in JS?
  render( x, y ) {
    this.ulx = x ;
    this.uly = y ;
    render( ) ;
  }
  
  render( ) {
    let patchWide = this.width / 2 ;
    let patchHigh = this.height / 2 ;
    let midX = this.ulx + patchWide;
    let midY = this.uly + patchHigh;
    let p1Color = this.patchColor1 ;
    let p2Color = this.patchColor2 ;
    
    console.log( midX + "," + midY) ;
    
    if( this.rotated ) {
      p1Color = this.patchColor2 ;
      p2Color = this.patchColor1 ;
    } 

    fill( p1Color ) ;
    noStroke();
    rect( this.ulx, this.uly, 100, 100) ;
    //fill( p2Color ) ;
    noFill();
    stroke(p2Color);
    strokeWeight(3);
    circle( this.ulx + 50, this.uly + 45, 45) ;
    circle( this.ulx + 35, this.uly + 70, 45) ;
    circle( this.ulx + 65, this.uly + 70, 45) ;
    circle( midX, midY + 10, 55) ;
    arc( midX, this.uly - 15, 100, 50, 0.45, 2.70, OPEN);
    line( midX, this.uly + 10, midX, this.uly + 95);
  }
}