// Some SVG colors for ya
// https://www.december.com/html/spec/colorsvgsvg.html
// https://p5js.org/reference/#/p5/color

// Standard "run once" component of Processing/P5JS idiom
function setup() {
  createCanvas(400, 400);
  background("red");

  // Not providing any interactivity right now
  noLoop();
  console.log("Starting...");

  myQuilt = new Quilt(4, 4, 100, color(0, 204, 128));

  let blocks = [];
  let backColor = color("grey");
  let color1 = color("seagreen");
  let color2 = color("darkorange");
  let color3 = color("black");
  let color4 = color("gold");

  // Create the 2d array
  for (let row = 0; row < 4; row++) {
    blocks[row] = new Array(4);
  }

  // Instantiate and add blocks to the Quilt
  for (let row = 0; row < 4; row++) {
    for (let col = 0; col < 4; col++) {

      blocks[0][0] = new NinePatch(100, 100, backColor, color1, color2);
      blocks[0][1] = new FourPatch(100, 100, backColor, color1, color2);
      blocks[0][2] = new FourPatch(100, 100, backColor, color1, color2);
      blocks[0][3] = new NinePatch(100, 100, backColor, color1, color2);
      blocks[1][0] = new FourPatch(100, 100, backColor, color1, color2);
      blocks[1][1] = new NewPatch(100, 100, backColor, color3, color4);
      blocks[1][2] = new NewPatch(100, 100, backColor, color3, color4);
      blocks[1][3] = new FourPatch(100, 100, backColor, color1, color2);
      blocks[2][0] = new FourPatch(100, 100, backColor, color1, color2);
      blocks[2][1] = new NewPatch(100, 100, backColor, color3, color4);
      blocks[2][2] = new NewPatch(100, 100, backColor, color3, color4);
      blocks[2][3] = new FourPatch(100, 100, backColor, color1, color2);
      blocks[3][0] = new NinePatch(100, 100, backColor, color1, color2);
      blocks[3][1] = new FourPatch(100, 100, backColor, color1, color2);
      blocks[3][2] = new FourPatch(100, 100, backColor, color1, color2);
      blocks[3][3] = new NinePatch(100, 100, backColor, color1, color2);

      myQuilt.addBlock(blocks[row][col], row, col);
    }
  }

  myQuilt.render();
}