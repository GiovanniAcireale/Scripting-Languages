// Derive class, specializes Block
class FourPatch extends Block {
  constructor(width, height, backColor, patchColor1, patchColor2 ) {
    super( width, height, backColor) ;
    this.patchColor1 = patchColor1 ;
    this.patchColor2 = patchColor2 ;
  }

  // Can you overload in JS?
  render( x, y ) {
    this.ulx = x ;
    this.uly = y ;
    render( ) ;
  }
  
  render( ) {
    let patchWide = this.width / 2 ;
    let patchHigh = this.height / 2 ;
    let midX = this.ulx + patchWide;
    let midY = this.uly + patchHigh;
    let p1Color = this.patchColor1 ;
    let p2Color = this.patchColor2 ;
    
    console.log( midX + "," + midY) ;
    
    noStroke();
    fill("black");
    rect( this.ulx, this.uly, 100, 100) ;
    
    fill( p1Color ) ;
    circle( this.ulx + patchWide * 0.5, this.uly + patchHigh * 0.5, 50) ;
    fill( p2Color ) ;
    circle( this.ulx + patchWide * 1.5, this.uly + patchHigh * 0.5, 50) ;
    fill( p2Color ) ;
    circle( this.ulx + patchWide * 0.5, this.uly + patchHigh * 1.5, 50) ;
    fill( p1Color ) ;
    circle( this.ulx + patchWide * 1.5, this.uly + patchHigh * 1.5, 50) ;

 
  }
}